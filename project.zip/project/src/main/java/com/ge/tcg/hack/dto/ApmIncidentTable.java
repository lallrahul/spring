package com.ge.tcg.hack.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="incidentTable")
public class ApmIncidentTable {
    
	@Id
	@SequenceGenerator(name="seq",sequenceName="incident_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	private long incidentId;
	
	@Column
	private String sensorId;
	@Column
	private String sensorName;
	@Column
	private double sensorData;
	@Column
	private String assetName;
	@Column
	//private java.sql.Timestamp initialTime;
	private Date initiatedTime;
	//@Column
	//private java.sql.Timestamp finalTime;
	@Column
	private String max_threshold_status;
	@Column
	private String min_threshold_status;
	public long getIncidentId() {
		return incidentId;
	}
	public void setIncidentId(long incidentId) {
		this.incidentId = incidentId;
	}
	public String getSensorId() {
		return sensorId;
	}
	public void setSensorId(String sensorId) {
		this.sensorId = sensorId;
	}
	public String getSensorName() {
		return sensorName;
	}
	public void setSensorName(String sensorName) {
		this.sensorName = sensorName;
	}
	public double getSensorData() {
		return sensorData;
	}
	public void setSensorData(double sensorData) {
		this.sensorData = sensorData;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public Date getInitiatedTime() {
		return initiatedTime;
	}
	public void setInitiatedTime(Date initiatedTime) {
		this.initiatedTime = initiatedTime;
	}
	public String getMax_threshold_status() {
		return max_threshold_status;
	}
	public void setMax_threshold_status(String max_threshold_status) {
		this.max_threshold_status = max_threshold_status;
	}
	public String getMin_threshold_status() {
		return min_threshold_status;
	}
	public void setMin_threshold_status(String min_threshold_status) {
		this.min_threshold_status = min_threshold_status;
	}
	
	
	
	
	
}
