package com.ge.tcg.hack.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="threshold_values")
public class ThresholdValuesEntity {

	@Id
	@SequenceGenerator(name="seq",sequenceName="threshold_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	@Column(name="THRESHOLD_ID")
	private long thresholdId;
	
	@Column(name="ASSET_NAME")
	private String assetName;
	@Column(name="SENSOR_NAME")
	private String sensorName;
	@Column(name="SENSOR_REAL_NAME")
	private String sensorRealName;
	@Column(name="THRESHOLD_MAX")
	private double thresholdMax;
	@Column(name="THRESHOLD_MIN")
	private double thresholdMin;
	@Column(name="RATED_VALUE")
	private double ratedValue;
	@Column(name="unit")
	private String unit;
	@Column(name="MESSAGE")
	private String message;
	@Column(name="SENSOR_TYPE")
	private String sensorType;
	@Column(name="status")
	private String status;
	@Column(name="preStatus")
	private String preStatus;
	@Column(name="channel")
	private String channel;
	public long getThresholdId() {
		return thresholdId;
	}
	public void setThresholdId(long thresholdId) {
		this.thresholdId = thresholdId;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getSensorName() {
		return sensorName;
	}
	public void setSensorName(String sensorName) {
		this.sensorName = sensorName;
	}
	public String getSensorRealName() {
		return sensorRealName;
	}
	public void setSensorRealName(String sensorRealName) {
		this.sensorRealName = sensorRealName;
	}
	public double getThresholdMax() {
		return thresholdMax;
	}
	public void setThresholdMax(double thresholdMax) {
		this.thresholdMax = thresholdMax;
	}
	public double getThresholdMin() {
		return thresholdMin;
	}
	public void setThresholdMin(double thresholdMin) {
		this.thresholdMin = thresholdMin;
	}
	public double getRatedValue() {
		return ratedValue;
	}
	public void setRatedValue(double ratedValue) {
		this.ratedValue = ratedValue;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getSensorType() {
		return sensorType;
	}
	public void setSensorType(String sensorType) {
		this.sensorType = sensorType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPreStatus() {
		return preStatus;
	}
	public void setPreStatus(String preStatus) {
		this.preStatus = preStatus;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	
	
	
	
	
	
}
