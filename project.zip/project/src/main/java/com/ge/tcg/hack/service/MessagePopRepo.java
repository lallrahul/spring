package com.ge.tcg.hack.service;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ge.tcg.hack.dto.MessagePopTable;

@Repository
public interface MessagePopRepo extends PagingAndSortingRepository<MessagePopTable, Long>{

	@Query("SELECT t FROM MessagePopTable t WHERE t.caseString = ?1 AND t.assetName= ?2")
	MessagePopTable fetchAlertMessage(String caseString,String assetName);
	
	
	@Modifying
	@Transactional
	@Query("UPDATE MessagePopTable t SET t.preStatus= ?1 WHERE t.assetName= ?2 ")
	void updatePreviousStatus(String status,String assetName);
	
	@Query("SELECT t.preStatus FROM MessagePopTable t WHERE t.caseString = ?1 AND t.assetName= ?2")
	String getPreStatus(String caseString,String assetName);
	
	@Query("SELECT t.message FROM MessagePopTable t WHERE t.caseString = ?1 AND t.assetName= ?2")
	String getMessage(String caseString,String assetName);
	
}
 //substitute made