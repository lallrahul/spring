package com.ge.tcg.hack.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;
import java.util.TimeZone;

import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ge.tcg.hack.dto.ApmIncidentTable;
import com.ge.tcg.hack.dto.AssetMonitoring;
import com.ge.tcg.hack.dto.MessagePopTable;
import com.ge.tcg.hack.dto.SensorAlertCheck;
import com.ge.tcg.hack.dto.ThresholdValuesEntity;
import com.ge.tcg.hack.repositories.IIncidentTableRepo;
import com.ge.tcg.hack.service.*;


@Service
@Transactional
public class AssetSummaryDetailsServiceImpl implements IAssetSummaryDetailsService {
	
	/*@Autowired
	SensorRepository sensorRepository;*/
	
	@Autowired
	ApmIncidentTableRepository apmRepository;
	
	@Autowired
	IThresholdValuesRepo thresholdValuesRepo;
	
	@Autowired
	IIncidentTableRepo incidentTableRepository;
	
	/*@Autowired
	MessagePopRepo messagePopRepo;*/
	
	/*@Autowired
	GetAllAssetNamesRepo getAllAssetNames;*/
	
	/*@Autowired
	GetAlertMessageRepo getAlertMessageRepo;
	
	@Autowired
	GetChannelRepo getChannelRepo;*/
	
	/*@Autowired
	ISkuRepository skuRepository;
	
	@Autowired
	IBomInfoRepository bomRepository;
	
	@Autowired
	IClassInfoRepository classRepository;
	
	@Autowired
	IDeviceInfoRepository deviceRepository;
	
	@Autowired
	IProductHierarchyRepository productRepository;*/

	

	
	@Override
	public String fetchAllSensorData(String sensorName) {
		String timeseriesUrl= new String("https://time-series-store-predix.run.aws-usw02-pr.ice.predix.io/v1/datapoints");
		
		
		//Logger logger = LoggerFactory.getLogger(MainApplication.class);
		
	//	System.out.println("i/p"+input);
		//AnalyticTimeseries analyticTimeseries = new AnalyticTimeseries();
		String success = null;
		int code = 0;
		String code1 = null;
		//1496633981787
		//String jsonString = "{  \"start\": \"40mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+ ",      \"order\": \"desc\"   } ] }";//, \"limit\":1
		String jsonString = "{  \"start\": \"5mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+ ",      \"order\": \"desc\"   } ] }";//, \"limit\":1

	//	logger.info("Start of Timeseries service ");
		HttpUriRequest request = new HttpPost(
				"https://time-series-store-predix.run.aws-usw02-pr.ice.predix.io/v1/datapoints");

		ObjectMapper mapper = new ObjectMapper();
		
		//HashMap<String, String> jsonDataMap = mapper.readValue(input, HashMap.class);
		//String urlValue = jsonDataMap.get("urlValue");

		//System.out.println("url"+urlValue);
		
		
					
			

		
		// HttpUriRequest request = new HttpPost(timeseriesUrl); 
		  
		int proxy_port = Integer.parseInt("80"); //<comment>

		HttpClientBuilder hcBuilder = HttpClients.custom();
		HttpHost proxy = new HttpHost("cis-india-pitc-bangalorez.proxy.corporate.ge.com", proxy_port, "http");//<comment>

		if (Boolean.parseBoolean("true")) {
			DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
			hcBuilder.setRoutePlanner(routePlanner);
		}

	//	logger.info("Setting headers for Timeseries service ");
		
		CloseableHttpClient client = hcBuilder.build();
		request.setHeader("Content-Type", "application/json");
		request.setHeader("Accept", "application/json");
		request.setHeader("Predix-Zone-Id", "6681de99-5e67-43ec-b0f3-fc83e7dfe394");
		request.setHeader("Authorization",
				"bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiIyOGJmODBmYjc1MTg0YTlmYmE3ZTAwNWQ3ZDZiOGM5ZSIsInN1YiI6ImhhY2tfY2xpZW50Iiwic2NvcGUiOlsidGltZXNlcmllcy56b25lcy42NjgxZGU5OS01ZTY3LTQzZWMtYjBmMy1mYzgzZTdkZmUzOTQudXNlciIsInRpbWVzZXJpZXMuem9uZXMuNjY4MWRlOTktNWU2Ny00M2VjLWIwZjMtZmM4M2U3ZGZlMzk0LmluZ2VzdCIsInRpbWVzZXJpZXMuem9uZXMuNjY4MWRlOTktNWU2Ny00M2VjLWIwZjMtZmM4M2U3ZGZlMzk0LnF1ZXJ5IiwidWFhLm5vbmUiLCJhbmFseXRpY3Muem9uZXMuZjkwNDhkZmEtZTE1ZC00YmZlLTkzZDctZmU1ODkyZTc5ZTlmLnVzZXIiLCJhenVxdWEuem9uZXMuNzRjM2Y5OGYtMWRlOS00MDk5LTk1YjMtMDJkMTE0NzEwNDQzLnVzZXIiLCJhbmFseXRpY3Muem9uZXMuNjY5NjZiMDQtNDk5YS00YzAzLWIzOGYtN2IyMjE4NTFjMDU1LnVzZXIiLCJ1YWEuYWRtaW4iLCJwcmVkaXgtYXNzZXQuem9uZXMuNjljZjBlZGItMmJhNy00MGZlLTg0ZTMtNjE0YTYxZmU0NmYwLnVzZXIiXSwiY2xpZW50X2lkIjoiaGFja19jbGllbnQiLCJjaWQiOiJoYWNrX2NsaWVudCIsImF6cCI6ImhhY2tfY2xpZW50IiwiZ3JhbnRfdHlwZSI6ImNsaWVudF9jcmVkZW50aWFscyIsInJldl9zaWciOiJkYzc2NzQ0IiwiaWF0IjoxNDgyMzkxMTkxLCJleHAiOjE1MTM5MjcxOTAsImlzcyI6Imh0dHBzOi8vZmNiN2VjOWEtM2QzNi00ZmI2LTllZDItN2M1ZTdkNjcxZjExLnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiZmNiN2VjOWEtM2QzNi00ZmI2LTllZDItN2M1ZTdkNjcxZjExIiwiYXVkIjpbImFuYWx5dGljcy56b25lcy42Njk2NmIwNC00OTlhLTRjMDMtYjM4Zi03YjIyMTg1MWMwNTUiLCJ1YWEiLCJhenVxdWEuem9uZXMuNzRjM2Y5OGYtMWRlOS00MDk5LTk1YjMtMDJkMTE0NzEwNDQzIiwidGltZXNlcmllcy56b25lcy42NjgxZGU5OS01ZTY3LTQzZWMtYjBmMy1mYzgzZTdkZmUzOTQiLCJhbmFseXRpY3Muem9uZXMuZjkwNDhkZmEtZTE1ZC00YmZlLTkzZDctZmU1ODkyZTc5ZTlmIiwiaGFja19jbGllbnQiLCJwcmVkaXgtYXNzZXQuem9uZXMuNjljZjBlZGItMmJhNy00MGZlLTg0ZTMtNjE0YTYxZmU0NmYwIl19.oc639-R01ex0EQaT_7FGK4Q2fNl2QUc0PAxhoOdzdNjoVATF4PV9Z1SQmTOHUx5jsv-3vDZTsOPTY9RayHd4TuK-BFqWrotd7WF4_z8jUe3R8z9eCJVL66M5xQSF3bgYUZIfAntpyoHKf9nD2JiqWwSyk5Lj3VQeo2GZRr0s4_kSuSdN8LfpdyVusJ1hNXfdgQHPUbBtMd2mLbXzk1vtdGWsuuE_JeUg8UZEPu4X3lCFqJUpdeNcfV6M_SQEA6F_lW0X5Zbvvmvwu1_ZvCOGPxDBcybZyxTsFgfnTZpZkwqXl3AWXtcrnJUpjfah27eYZsKw6u-wymOpAs3NupV3vQ");

		try {
		StringEntity stringEntity = new StringEntity(jsonString);
		((HttpPost) request).setEntity(stringEntity);

		HttpResponse response;
		
		//	logger.info("Executing Timeseries service ");
			
			response = client.execute(request);

			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
		//	logger.info("Executed Timeseries service ");
				
			}
			success = result.toString();
			
			System.out.println("success " + success);
		//	logger.info("Calling calculationOnValues function");
		//	code = analyticTimeseries.calculationOnValues(success);
		//	logger.info("After Calling calculationOnValues function");

			//code1 = Integer.toString(code);
			

		} catch (Exception e) {
			success = "Analytics Execution Failed "+e.getMessage();
			e.printStackTrace();

		} finally {
			try {
				client.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	//	return mapper.writeValueAsString(code1);

		
		
		return success;
	}
  //function for calculating the average value
/*
	@Override
	public String fetchAverageViaSensor() {
		// TODO Auto-generated method stub
		return null;
	}

*/
	
	
	 
	
	
/*	@Override
	public Map<String,String> fetchAverageViaSensor() {
		String timeseriesUrl= new String("https://time-series-store-predix.run.aws-usw02-pr.ice.predix.io/v1/datapoints");
		
		
		//Logger logger = LoggerFactory.getLogger(MainApplication.class);
		
	//	System.out.println("i/p"+input);
		//AnalyticTimeseries analyticTimeseries = new AnalyticTimeseries();
		String success = null;
		int code = 0;
		String code1 = null;
		//String jsonString = "{  \"start\": \"5mi-ago\",  \"tags\": [ {  \"name\":\"trnTempSn\",\"aggregations\":[{\"type\":\"avg\",\"interval\":\"5mi\"}], \"order\": \"desc\"   } ] }";
		String jsonString = "{  \"start\": \"5mi-ago\",  \"tags\": [ {  \"name\": \"trnTempSn\",      \"order\": \"desc\"   } ] }";
		//String jsonString = "{  \"start\": \"45mi-ago\",  \"tags\": [ {  \"name\": \"trnTempSn\",      \"order\": \"desc\"   } ] }";
		//\"tags\": [ {  \"name\": \"Apm_pentographTemperatureSensor\",  \"aggregations\" : [{\"type\": \"avg\", \"interval\": \"5mi\"}] } ],\"start\": \"5mi-ago\"

	//	logger.info("Start of Timeseries service ");
		HttpUriRequest request = new HttpPost(
				"https://time-series-store-predix.run.aws-usw02-pr.ice.predix.io/v1/datapoints");

		ObjectMapper mapper = new ObjectMapper();
		
		//HashMap<String, String> jsonDataMap = mapper.readValue(input, HashMap.class);
		//String urlValue = jsonDataMap.get("urlValue");

		//System.out.println("url"+urlValue);
		
		
					
			

		
		  //HttpUriRequest request = new HttpPost(timeseriesUrl); 
		  
	    int proxy_port = Integer.parseInt("80");//comment

		HttpClientBuilder hcBuilder = HttpClients.custom();
		HttpHost proxy = new HttpHost("cis-india-pitc-bangalorez.proxy.corporate.ge.com", proxy_port, "http");//comment

		if (Boolean.parseBoolean("true")) {
			DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
			hcBuilder.setRoutePlanner(routePlanner);
		}
	//	logger.info("Setting headers for Timeseries service ");
		
		CloseableHttpClient client = hcBuilder.build();
		request.setHeader("Content-Type", "application/json");
		request.setHeader("Accept", "application/json");
		request.setHeader("Predix-Zone-Id", "6681de99-5e67-43ec-b0f3-fc83e7dfe394");
		request.setHeader("Authorization",
				"bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiIyOGJmODBmYjc1MTg0YTlmYmE3ZTAwNWQ3ZDZiOGM5ZSIsInN1YiI6ImhhY2tfY2xpZW50Iiwic2NvcGUiOlsidGltZXNlcmllcy56b25lcy42NjgxZGU5OS01ZTY3LTQzZWMtYjBmMy1mYzgzZTdkZmUzOTQudXNlciIsInRpbWVzZXJpZXMuem9uZXMuNjY4MWRlOTktNWU2Ny00M2VjLWIwZjMtZmM4M2U3ZGZlMzk0LmluZ2VzdCIsInRpbWVzZXJpZXMuem9uZXMuNjY4MWRlOTktNWU2Ny00M2VjLWIwZjMtZmM4M2U3ZGZlMzk0LnF1ZXJ5IiwidWFhLm5vbmUiLCJhbmFseXRpY3Muem9uZXMuZjkwNDhkZmEtZTE1ZC00YmZlLTkzZDctZmU1ODkyZTc5ZTlmLnVzZXIiLCJhenVxdWEuem9uZXMuNzRjM2Y5OGYtMWRlOS00MDk5LTk1YjMtMDJkMTE0NzEwNDQzLnVzZXIiLCJhbmFseXRpY3Muem9uZXMuNjY5NjZiMDQtNDk5YS00YzAzLWIzOGYtN2IyMjE4NTFjMDU1LnVzZXIiLCJ1YWEuYWRtaW4iLCJwcmVkaXgtYXNzZXQuem9uZXMuNjljZjBlZGItMmJhNy00MGZlLTg0ZTMtNjE0YTYxZmU0NmYwLnVzZXIiXSwiY2xpZW50X2lkIjoiaGFja19jbGllbnQiLCJjaWQiOiJoYWNrX2NsaWVudCIsImF6cCI6ImhhY2tfY2xpZW50IiwiZ3JhbnRfdHlwZSI6ImNsaWVudF9jcmVkZW50aWFscyIsInJldl9zaWciOiJkYzc2NzQ0IiwiaWF0IjoxNDgyMzkxMTkxLCJleHAiOjE1MTM5MjcxOTAsImlzcyI6Imh0dHBzOi8vZmNiN2VjOWEtM2QzNi00ZmI2LTllZDItN2M1ZTdkNjcxZjExLnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiZmNiN2VjOWEtM2QzNi00ZmI2LTllZDItN2M1ZTdkNjcxZjExIiwiYXVkIjpbImFuYWx5dGljcy56b25lcy42Njk2NmIwNC00OTlhLTRjMDMtYjM4Zi03YjIyMTg1MWMwNTUiLCJ1YWEiLCJhenVxdWEuem9uZXMuNzRjM2Y5OGYtMWRlOS00MDk5LTk1YjMtMDJkMTE0NzEwNDQzIiwidGltZXNlcmllcy56b25lcy42NjgxZGU5OS01ZTY3LTQzZWMtYjBmMy1mYzgzZTdkZmUzOTQiLCJhbmFseXRpY3Muem9uZXMuZjkwNDhkZmEtZTE1ZC00YmZlLTkzZDctZmU1ODkyZTc5ZTlmIiwiaGFja19jbGllbnQiLCJwcmVkaXgtYXNzZXQuem9uZXMuNjljZjBlZGItMmJhNy00MGZlLTg0ZTMtNjE0YTYxZmU0NmYwIl19.oc639-R01ex0EQaT_7FGK4Q2fNl2QUc0PAxhoOdzdNjoVATF4PV9Z1SQmTOHUx5jsv-3vDZTsOPTY9RayHd4TuK-BFqWrotd7WF4_z8jUe3R8z9eCJVL66M5xQSF3bgYUZIfAntpyoHKf9nD2JiqWwSyk5Lj3VQeo2GZRr0s4_kSuSdN8LfpdyVusJ1hNXfdgQHPUbBtMd2mLbXzk1vtdGWsuuE_JeUg8UZEPu4X3lCFqJUpdeNcfV6M_SQEA6F_lW0X5Zbvvmvwu1_ZvCOGPxDBcybZyxTsFgfnTZpZkwqXl3AWXtcrnJUpjfah27eYZsKw6u-wymOpAs3NupV3vQ");
		String sensorData=null;
		try {
		StringEntity stringEntity = new StringEntity(jsonString);
		((HttpPost) request).setEntity(stringEntity);

		HttpResponse response;
		
		//	logger.info("Executing Timeseries service ");
			
			response = client.execute(request);

			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
		//	logger.info("Executed Timeseries service ");
				
			}
			success = result.toString();
			JSONArray resultsArr=new JSONArray();
			String[] valuesArray = new String[3];
			JSONParser parser=new JSONParser();
			JSONObject jsonObj=(JSONObject) parser.parse(success.toString());
			JSONArray tagsArr=(JSONArray) jsonObj.get("tags");
			for (Object tagsObj : tagsArr) {
				JSONObject tagObj=(JSONObject) tagsObj;
				resultsArr=(JSONArray) tagObj.get("results");
				System.out.println("%%%%%%%%%"+resultsArr.toString());
			}
			for (Object valueObj : tagsArr) {
				JSONObject valuesObj=(JSONObject) valueObj;
				System.out.println("value obj is "+valueObj);
				valuesArray = (String[]) valuesObj.get("values");
				System.out.println("values array is "+valuesArray);
			}
			if(valuesArray!=null){
				sensorData = valuesArray[1]; //check here
			}else{
				sensorData="0";
			}
			
			
			System.out.println("success " + success);
		//	logger.info("Calling calculationOnValues function");
		//	code = analyticTimeseries.calculationOnValues(success);
		//	logger.info("After Calling calculationOnValues function");

			//code1 = Integer.toString(code);
			

		} catch (Exception e) {
			success = "Analytics Execution Failed "+e.getMessage();
			e.printStackTrace();

		} finally {
			try {
				client.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	//	return mapper.writeValueAsString(code1);
System.out.println("\n checkpoint1................. \n");
		Map<String,String> averageList=returnValueFromTimeseries(success); *//************************************//*
		
	//setting up an average threshold value
		
		String value=averageList.get("trnTempSn");
		String threshold_status=null;
	*//************************************************************************************
	 * * *//*	
		
			
	*//************************************************************************************
	 * * *//*	
		
		java.util.Date date = new java.util.Date();
		System.out.println(new Timestamp(date.getTime()));

		System.out.println("hello");
		int threshold_value=sensorRepository.getValue();                                       //setting threshold value
		System.out.println("value is "+threshold_value);
		if ( Double.parseDouble(value) < threshold_value ) {  
			threshold_status="N";
		}
		else{
			threshold_status="Y";
			ApmIncidentTable apmIncidentTable = new ApmIncidentTable();
			apmIncidentTable.setSensorId("Apm_pentographTemperatureSensor");
			System.out.println("in method");
			apmIncidentTable.setSensorData(Double.parseDouble(value)); //check sensor data
		//	String timeStamp = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a").format(Calendar.getInstance().getTime());
			
           // String timeStamp =fmt.format(dateTime);
			//apmIncidentTable.setInitialTime(new Timestamp(date.getTime()));
			
			     Format formatter = new SimpleDateFormat("dd MMMM yyyy hh:mm:ss a"); 
                   String s = formatter.format(new Date());
			
			apmIncidentTable.setInitialTime(s);
			   apmIncidentTable.setFinalTime(null);   
			//apmIncidentTable.setThreshold_status(threshold_status);
			apmIncidentTable = apmRepository.save(apmIncidentTable);  //entering data in table
			System.out.println("inc table is "+apmIncidentTable);
		}
		averageList.put("reached_Threshold", threshold_status);
		return averageList;
		}*/
	
	public Map<String,String> returnValueFromTimeseries(String timeseries){
		//org.json.JSONObject json=new org.json.JSONObject(timeseries);
	//	System.out.println("json" + json);
		
		//<comment
		Map<String,String> sensorwithValue=new HashMap<String,String>();
		//List<Integer> valuesOfSensor=null;
		String name=null;
		double average=0;

		double sum=0;
		//int responseCode = 0;
		/********************************************************/
		JSONParser parser = new JSONParser();

		JSONObject json=null;
		try {
			json = (JSONObject) parser.parse(timeseries);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("JSON :" + json);
		//List<SensorEntity> sensors = new ArrayList<SensorEntity>();
		//List<SiteAggEntity> sites = new ArrayList<SiteAggEntity>();

		//List<SensorEntity> sensorEntities = null;
	//	List<SiteAggEntity> siteEntities = null;
		// SensorEntity sensorEntity=null;

		JSONArray tags = (JSONArray) json.get("tags");
		for (Object t : tags) {
			// valuesOfSensor=new ArrayList<Integer>();
			JSONObject tag = (JSONObject) t;
			 name = (String) tag.get("name");

			
			JSONArray results = (JSONArray) tag.get("results");
			for (Object r : results) 
			{
				JSONObject result = (JSONObject) r;
				JSONArray values = (JSONArray) result.get("values");
				
				List<List<Object>> val = values;
				int h = 0;
			//	count = val.size();
				average=0;
				sum=0;
				// LOOP OF VALUES
				while (h < val.size()) 
				{
				
				
				
				System.out.println("Data from sensor: " + val.get(h).get(1));
				if(val.get(h).get(1).toString().equalsIgnoreCase("nan"))
				{
					h++;
					continue;
				}
				else
				{
				sum=sum+new Double((val.get(h).get(1)).toString());
				//average=average+ (Double)val.get(h).get(1);
				
				h++;
				}
				}
				if(val.size()==0)
				{
					average=0;
				}
				else
				{
				average=sum/val.size();
				}
				System.out.println("average"+average);
				//valuesOfSensor.add((Integer) val.get(h).get(1));
				sensorwithValue.put(name, String.valueOf(average));
				
			}
		}
		//sensorwithValue.put(name, valuesOfSensor);
		
		//average(sensorwithValue);
				System.out.println("map@@@@@@"+sensorwithValue);
				return sensorwithValue;
	
	}
	
	
	
	
	public List<ApmIncidentTable> fetchIncidentTable(String assetName){
		
		List<ApmIncidentTable> incidentTable_list = new ArrayList<ApmIncidentTable>();
		
		List<ApmIncidentTable> iList = (List<ApmIncidentTable>) apmRepository.fetchIncidentTable(assetName);
		for(ApmIncidentTable apmIncidentTable:iList){
			incidentTable_list.add(apmIncidentTable);
		}
		
		
		System.out.println(incidentTable_list);
		return incidentTable_list;
		
	}









	@Override
	public List<AssetMonitoring> assetMonitor(String assetName) {
		
		//List<ThresholdValuesEntity> thresholdList=(List<ThresholdValuesEntity>) thresholdValuesRepo.findAll();
		List<ThresholdValuesEntity> thresholdList=(List<ThresholdValuesEntity>) thresholdValuesRepo.fetchThresholdValues(assetName);
		AssetMonitoring assetMonitoring=null;
		List<AssetMonitoring> assetMonitorList=new ArrayList<AssetMonitoring>();
		
		for (ThresholdValuesEntity thresholdValuesEntity : thresholdList) {
			if(!thresholdValuesEntity.getSensorName().equals("taoWindVal")){
			assetMonitoring=new AssetMonitoring();
			String sensorName=thresholdValuesEntity.getSensorName();
			String sensorRealName=thresholdValuesEntity.getSensorRealName();
			String unit=thresholdValuesEntity.getUnit();
		   
			double minValue=thresholdValuesEntity.getThresholdMin();
			double maxValue=thresholdValuesEntity.getThresholdMax();
			assetMonitoring.setRatedValue(thresholdValuesEntity.getRatedValue());
			assetMonitoring.setSensorTag(sensorName);
			assetMonitoring.setSensorRealName(sensorRealName);
			assetMonitoring.setSensorType(thresholdValuesEntity.getSensorType());
			assetMonitoring.setUnit(unit);
			assetMonitoring.setThresholdMin(minValue);
			assetMonitoring.setThresholdMax(maxValue);
			//String timeseriesData=fetchAllSensorData(sensorName);
			//System.out.println(value);
			
			/****************************************************************/
			/*JSONParser parser = new JSONParser();
			String name=null;
			double currentValue= 0.0;
			JSONObject json=null;
			try {
				json = (JSONObject) parser.parse(timeseriesData);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("JSON :" + json);

			JSONArray tags = (JSONArray) json.get("tags");
			for (Object t : tags) {
				JSONObject tag = (JSONObject) t;
				 name = (String) tag.get("name");

				
				JSONArray results = (JSONArray) tag.get("results");
				for (Object r : results) 
				{
					JSONObject result = (JSONObject) r;
					JSONArray values = (JSONArray) result.get("values");
					
					List<List<Object>> val = values;
					int h = 0;
					
					while (h < val.size()) 
					{
					long v = (long) val.get(h).get(1);
					currentValue = v;
					System.out.println(currentValue);
					
					h++;
					}
				}//while end
			}//for end
*/
			
			//double currentValue=fetchTimeSeriesValue(timeseriesData);
			/*TimeZone.setDefault(TimeZone.getTimeZone("IST"));
			Format formatter = new SimpleDateFormat("EE dd MMMM yyyy hh:mm:ss a"); 
            String mtrReading = formatter.format(new Date());//get time stamp 
            Date localDate=new Date();*/
            //localDate.
			/*DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd MMMM yyyy hh:mm:ss a");
			LocalDateTime now = LocalDateTime.now();*/
			
			SimpleDateFormat sdfDate = new SimpleDateFormat("EE dd MMMM yyyy hh:mm:ss a");//dd/MM/yyyy
			
			
			Date date=new Date();
			System.out.println("system date......"+date);
			//date.setTime(System.currentTimeMillis());
			Calendar cal=Calendar.getInstance();
			cal.setTime(date);
			cal.add(Calendar.MINUTE, 30);
			cal.add(Calendar.HOUR, 5);
			String istDate=sdfDate.format(cal.getTime());
			System.out.println("this the date we want...."+istDate);
			
			
		   /* Date now = new Date();
		    String strDate = sdfDate.format(now);*/
            System.out.println("DATE IS********"+istDate);
            
			//System.out.println("DATE is***************"+now);
            assetMonitoring.setLatestValue(Double.parseDouble(new DecimalFormat("##.##").format(fetchSingleSensorLatestValue(sensorName))));
            //Double.parseDouble(new DecimalFormat("##.##").format(fetchSingleSensorLatestValue(sensorName));
            assetMonitoring.setLastMtrReading(istDate);
            double currentValue=fetchSingleSensorAvgValue(sensorName); //eliminated fetchAllSensorData dependency here
            assetMonitoring.setCurrentValue(currentValue);
            if(currentValue>maxValue)
            {
            	assetMonitoring.setAlertStatus("Y");
            	assetMonitoring.setDeltaToUpperThreshold(101);
            	assetMonitoring.setDeltaToLowerThreshold(101);	
            }
            else if(currentValue<minValue){
            	assetMonitoring.setAlertStatus("Y");
            	assetMonitoring.setDeltaToUpperThreshold(101);
            	assetMonitoring.setDeltaToLowerThreshold(101);
            	//double d2t = ((currentValue-minValue)/minValue)*100;
            	
            }
            else{
            	assetMonitoring.setAlertStatus("N");
            	//new DecimalFormat("##.##").format(((maxValue-currentValue)/maxValue)*100);
            	
            	double ud2t = Double.parseDouble(new DecimalFormat("##.###").format(((maxValue-currentValue)/maxValue)*100));
            	//Double.parseDouble(new DecimalFormat("##.##").format(-(100-ud2t));
            	assetMonitoring.setDeltaToUpperThreshold(ud2t);
            	double ld2t=Double.parseDouble(new DecimalFormat("##.###").format((100-ud2t)));
            	assetMonitoring.setDeltaToLowerThreshold(ld2t);
            	//double d2t = ((maxValue-currentValue)/maxValue)*100;
            	
            }
            
            
            assetMonitorList.add(assetMonitoring);
			}
			
		}		//ending of for each
		
		
		return assetMonitorList;
	}





	
	
	public double fetchTimeSeriesValue(String jsonString){
		JSONParser parser = new JSONParser();
		String name=null;
		double currentValue= 0.0;
		JSONObject json=null;
		try {
			json = (JSONObject) parser.parse(jsonString);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("JSON :" + json);
		//List<SensorEntity> sensors = new ArrayList<SensorEntity>();
		//List<SiteAggEntity> sites = new ArrayList<SiteAggEntity>();

		//List<SensorEntity> sensorEntities = null;
	//	List<SiteAggEntity> siteEntities = null;
		// SensorEntity sensorEntity=null;

		JSONArray tags = (JSONArray) json.get("tags");
		for (Object t : tags) {
			// valuesOfSensor=new ArrayList<Integer>();
			JSONObject tag = (JSONObject) t;
			 name = (String) tag.get("name");

			
			JSONArray results = (JSONArray) tag.get("results");
			for (Object r : results) 
			{
				JSONObject result = (JSONObject) r;
				JSONArray values = (JSONArray) result.get("values");
				
				List<List<Object>> val = values;
				int h = 0;
			//	count = val.size();
				
				// LOOP OF VALUES
				
				while (h < val.size()) 
				{
				//System.out.println("Data from sensor: " + val.get(h).get(1));
					Object o = (val.get(h).get(1));
					if(o.getClass().equals(java.lang.Double.class)){
						
						System.out.println("in if of DECIMAL FORMAT......");
						double v = (double) val.get(h).get(1);
						 currentValue = v;
						 //Double.parseDouble(new DecimalFormat("##.##").format(v))
					}
					else{	
						System.out.println("in else of DECIMAL FORMAT......");
						System.out.println("avg value coming......"+(long) val.get(h).get(1));
				//double v = Double.longBitsToDouble((long) val.get(h).get(1));
						double v=(long) val.get(h).get(1);
				 currentValue = v;
					}
				//double var=v;
				//System.out.println(v);
				
				
				/*if(val.get(h).get(1).toString().equalsIgnoreCase("nan"))
				{
					h++;
					continue;
				}
				else
				{
				sum=sum+new Double((val.get(h).get(1)).toString());
				//average=average+ (Double)val.get(h).get(1);
				
				h++;
				}*/
				h++;
				}//while end
			}//for end
		}//for end
		System.out.println("avg value is..in function"+currentValue);
		return Double.parseDouble(new DecimalFormat("##.###").format(currentValue));
		//return currentValue;
		
	}

	
	@Override
	public List<JSONObject> checkAverageData(String assetName) {
		List<ThresholdValuesEntity> sensorList=thresholdValuesRepo.fetchThresholdValues(assetName);
		List<JSONObject> jsonList=new ArrayList<JSONObject>();
		JSONObject jsObject=null;
		for(ThresholdValuesEntity thresholdValuesEntity : sensorList) {
			jsObject=new JSONObject();
			String sensorName = thresholdValuesEntity.getSensorName();
			jsObject.put("sensorName", sensorName);
			jsObject.put("sensorRealName",thresholdValuesEntity.getSensorRealName());
			jsObject.put("minThreshold", thresholdValuesEntity.getThresholdMin());
			jsObject.put("maxThreshold", thresholdValuesEntity.getThresholdMax());
			
			double minThreshold=thresholdValuesEntity.getThresholdMin();
			double maxThreshold=thresholdValuesEntity.getThresholdMax();
			String sensorRealName=thresholdValuesEntity.getSensorRealName();
			String jsonString = "{  \"start\": \"5mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+",\"aggregations\":[{\"type\":\"avg\",\"interval\":\"5mi\"}], \"order\": \"desc\"   } ] }";
			//String jsonString = "{  \"start\": \"45mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+",\"aggregations\":[{\"type\":\"avg\",\"interval\":\"45mi\"}], \"order\": \"desc\"   } ] }";
			String success = jsonURLParser(jsonString);
			System.out.println("sucess running correct......."+success);
			double avgValue=fetchTimeSeriesValue(success);
			System.out.println("avg value is................"+avgValue);
			if(avgValue>maxThreshold){
				String maxState = "Y";
				String minState = "N";
				jsObject.put("maxThresholdStatus",maxState);
				jsObject.put("minThresholdStatus", minState);
				
				jsObject.put("messageMax", "VALUE IS ABOVE MAX");
				raiseIncident(assetName,sensorName,sensorRealName,avgValue,minState,maxState);
				jsObject.put("messageMin","NA");
			}
			else if (avgValue<minThreshold) {
				String minState = "Y";
				String maxState = "N";
				jsObject.put("minThresholdStatus",minState);
				jsObject.put("maxThresholdStatus", maxState);
				jsObject.put("messageMin","VALUE IS below MIN");
				raiseIncident(assetName,sensorName,sensorRealName,avgValue,minState,maxState);   //comment this for now
				jsObject.put("messageMax", "NA");
			}
			else{
				jsObject.put("maxThresholdStatus","N");
				jsObject.put("minThresholdStatus","N");
				jsObject.put("messageMax", "VALUE IS OK");
				jsObject.put("messageMin","VALUE IS OK");
			}
			jsObject.put("avgData", avgValue);
			jsonList.add(jsObject);
		}
		
		return jsonList;
	}
	
	
	@Override
	public String generateAlertMessage(String caseCode) {
         int alertLevel=0;
       
         String alertMessage="";
		for(int count = 0; count < caseCode.length() ; count++)
		   {  
		     if(caseCode.charAt(count)=='Y')
		       {
			    	alertLevel++;
		       }
		   }
		  
		    int criticalIntensity=(alertLevel/caseCode.length())*100;
		    switch(criticalIntensity){
		    case 0: 
		    	alertMessage="All SYSTEMS OK";
		    	break;
		    case 16: 
		    	alertMessage="FEW SYSTEMS CRITICAL";
		    	break;
		    case 33:
		    	alertMessage="SOME SYSTEM CRITICAL";
		    	break;
		    case 50:
		    	alertMessage="MAJOR SYSTEM CRITCAL";
		    	break;
		    case 66:
		    	alertMessage="MOST SYSTEM CRITICAL";
		    	break;
		    case 83:
		    	alertMessage="MAJOR ALERT!";
		    	break;
		    case 100:
		    	alertMessage="HIGH ALERT!";
		    	break;
		    default:
		    	alertMessage="SYSTEM UNABLE TO DIAGNOSE! TRY AGAIN";
		    	break;
		    }
		  
		
		return alertMessage;
	}
	
	
	@Override
	public JSONObject alertMessagePop(String assetName) {
		List<MessagePopTable> msgPopList=new ArrayList<MessagePopTable>();
		String alertMsg="";
		//check dis
		List<ThresholdValuesEntity> sensorList=thresholdValuesRepo.fetchThresholdValues(assetName);
		int caseChecker=0;
		List<JSONObject> jsonList=new ArrayList<JSONObject>();
		JSONObject jsObject=null;
		String caseCode="";
		String caseString="";
		for (ThresholdValuesEntity thresholdValuesEntity : sensorList) {
			jsObject=new JSONObject();
			double minThreshold=thresholdValuesEntity.getThresholdMin();
			double maxThreshold=thresholdValuesEntity.getThresholdMax();
			String sensorName = thresholdValuesEntity.getSensorName();
			String sensorRealName=thresholdValuesEntity.getSensorRealName();
			String jsonString = "{  \"start\": \"5mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+",\"aggregations\":[{\"type\":\"avg\",\"interval\":\"5mi\"}], \"order\": \"desc\"   } ] }";
			//String jsonString = "{  \"start\": \"45mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+",\"aggregations\":[{\"type\":\"avg\",\"interval\":\"45mi\"}], \"order\": \"desc\"   } ] }";
			String success = jsonURLParser(jsonString);
			double avgValue=fetchTimeSeriesValue(success);
			if(avgValue>maxThreshold){
				caseCode=caseCode+"Y";
				caseChecker++;
				String minState="NA";
				String maxState="AVG IS ABOVE MAX";
				raiseIncident(assetName, sensorName,sensorRealName, avgValue, minState, maxState);
			}
			else if(avgValue<minThreshold){
				caseCode=caseCode+"Y";
				caseChecker++;
				String minState="AVG IS BELOW MIN";
				String maxState="NA";
				raiseIncident(assetName, sensorName,sensorRealName, avgValue, minState, maxState);
			}
			else{
				caseCode=caseCode+"N";
			}
			
		}
		if(caseChecker==0)
			caseString="N";
		else
			caseString="Y";
		alertMsg=generateAlertMessage(caseCode);
		//System.out.println("CaseCode is............."+caseCode+"for sensor.....");
		//MessagePopTable msgQueryReturn= messagePopRepo.fetchAlertMessage(caseCode,assetName);
		//System.out.println("msg is returning....."+msgQueryReturn);
		//jsObject.put("message",msgQueryReturn.getMessage());
		jsObject.put("message",alertMsg);
		jsObject.put("asset",assetName);
		jsObject.put("caseString",caseString);
		
		
		
		
		System.out.println("msg pop list return........"+msgPopList);
		return jsObject;
	}
	
	@Override
	 public String calculateCaseCode(String assetName){
		String caseCode = "";
		
			List<ThresholdValuesEntity> sensorList=(List<ThresholdValuesEntity>) thresholdValuesRepo.fetchThresholdValues(assetName);
			System.out.println(sensorList);
			//String caseString="";
			//int caseChecker=0;
			for (ThresholdValuesEntity thresholdValuesEntity : sensorList) {
				double minThreshold=thresholdValuesEntity.getThresholdMin();
				double maxThreshold=thresholdValuesEntity.getThresholdMax();
				String sensorName = thresholdValuesEntity.getSensorName();
				String jsonString = "{  \"start\": \"5mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+",\"aggregations\":[{\"type\":\"avg\",\"interval\":\"5mi\"}], \"order\": \"desc\"   } ] }";
				//String jsonString = "{  \"start\": \"45mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+",\"aggregations\":[{\"type\":\"avg\",\"interval\":\"45mi\"}], \"order\": \"desc\"   } ] }";
				String success = jsonURLParser(jsonString);
				System.out.println("sucess......."+success);
				double avgValue=fetchTimeSeriesValue(success);
				//Double.parseDouble(new DecimalFormat("##.##").format(fetchTimeSeriesValue(success)));
				System.out.println("in loop of calculateCaseCode..........for asset"+assetName);
				if(avgValue>maxThreshold){
					caseCode=caseCode+"Y";
					//caseChecker++;
				}
				else if(avgValue<minThreshold){
					caseCode=caseCode+"Y";
					//caseChecker++;
				}
				else{
					caseCode=caseCode+"N";
				}
				
			}
		
		
		return caseCode;
		 
	 }
	
	@Override
	public List<SensorAlertCheck> checkEachSensor() {
		
		List<SensorAlertCheck> sensorAlertList=new ArrayList<SensorAlertCheck>();
		SensorAlertCheck sensorAlertCheck=null;
		List<String> assetNameList= thresholdValuesRepo.fetchDistinctAssetName();//getAllAssetNames.fetchDistinctAssetName();
		System.out.println("asetName List is...."+assetNameList);
		for (String assetName : assetNameList) {
			sensorAlertCheck=new SensorAlertCheck();
			String caseString=calculateCaseCode(assetName);//caseCode is calcula
			if(caseString.contains("Y")){
				String newStatus="STOP";
				thresholdValuesRepo.updateStatus(newStatus, assetName);
			}
			else{
				String newStatus="START";
				thresholdValuesRepo.updateStatus(newStatus, assetName);
			}
			System.out.println("caseCode........"+caseString+"for asset......"+assetName);
			String alertMsg=thresholdValuesRepo.fetchStatus(assetName);//getAlertMessageRepo.fetchStatus(caseString,assetName);// fetch query in loop
			System.out.println("alertMsg*****************"+alertMsg);
			String preStatus=thresholdValuesRepo.getPreStatus(assetName);//messagePopRepo.getPreStatus(caseString,assetName);
			System.out.println("preStatus****************"+preStatus);
			if(preStatus.equals(alertMsg)){
				//String blank="";
				String channel=thresholdValuesRepo.fetchChannel(assetName);//getChannelRepo.fetchChannel(caseString,assetName); 
				//String message=messagePopRepo.getMessage(caseString, assetName);
				String message=generateAlertMessage(caseString);
				sensorAlertCheck.setAlertMessage("");// send blank if previous state is equal to current
				sensorAlertCheck.setChannel(channel);
				sensorAlertCheck.setMessage(message);
				System.out.println("IF condition ........");
				sensorAlertCheck.setAssetName(assetName);
				sensorAlertList.add(sensorAlertCheck);
			}
			else{
				//messagePopRepo.updatePreviousStatus(alertMsg,assetName);
				thresholdValuesRepo.updatePreviousStatus(alertMsg, assetName);// the pre state gets updated when state changes
				//String channel=getChannelRepo.fetchChannel(caseString,assetName);
				//String message=messagePopRepo.getMessage(caseString, assetName);
				String channel=thresholdValuesRepo.fetchChannel(assetName);
				String message=generateAlertMessage(caseString);
				sensorAlertCheck.setMessage(message);
				sensorAlertCheck.setAlertMessage(alertMsg);
				sensorAlertCheck.setChannel(channel);
				sensorAlertCheck.setAssetName(assetName);
				sensorAlertList.add(sensorAlertCheck);
			}
			
			
		}
		
		return sensorAlertList;
		
		
		
	}
	
	
	private void raiseIncident(String assetName, String sensorName,String sensorRealName, double avgValue, String minState, String maxState) {
		// TODO Auto-generated method stub
		
		ApmIncidentTable objApmIncidentTable = new ApmIncidentTable();
		
		objApmIncidentTable.setAssetName(assetName);
		objApmIncidentTable.setSensorId(sensorName);
		objApmIncidentTable.setSensorName(sensorRealName);
		objApmIncidentTable.setSensorData(avgValue);
		objApmIncidentTable.setMax_threshold_status(maxState);
		objApmIncidentTable.setMin_threshold_status(minState);
		//SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMMM yyyy hh:mm:ss a");
		//Date currentDate = new Date();
		/*try {
			Date formattedDate = dateFormat.parse(source)
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	    // Format formatter = new SimpleDateFormat("dd MMMM yyyy hh:mm:ss a"); 
         //String s = formatter.format(new Date());
		Date date = new Date();
		
		objApmIncidentTable.setInitiatedTime(date);
		apmRepository.save(objApmIncidentTable);
		
	}
	public String jsonURLParser(String jsonStr) {
		String timeseriesUrl= new String("https://time-series-store-predix.run.aws-usw02-pr.ice.predix.io/v1/datapoints");
		
		
		//Logger logger = LoggerFactory.getLogger(MainApplication.class);
		
	//	System.out.println("i/p"+input);
		//AnalyticTimeseries analyticTimeseries = new AnalyticTimeseries();
		String success = null;
		int code = 0;
		String code1 = null;
		//1496633981787
		//String jsonString = "{  \"start\": \"5mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+ ",      \"order\": \"desc\", \"limit\":1   } ] }";
		String jsonString = jsonStr;

	//	logger.info("Start of Timeseries service ");
		HttpUriRequest request = new HttpPost(
				"https://time-series-store-predix.run.aws-usw02-pr.ice.predix.io/v1/datapoints");

		ObjectMapper mapper = new ObjectMapper();
		
		//HashMap<String, String> jsonDataMap = mapper.readValue(input, HashMap.class);
		//String urlValue = jsonDataMap.get("urlValue");

		//System.out.println("url"+urlValue);
		
		
					
			

		
		// HttpUriRequest request = new HttpPost(timeseriesUrl); 
		  
		int proxy_port = Integer.parseInt("80"); //<comment>

		HttpClientBuilder hcBuilder = HttpClients.custom();
		HttpHost proxy = new HttpHost("cis-india-pitc-bangalorez.proxy.corporate.ge.com", proxy_port, "http");//<comment>

		if (Boolean.parseBoolean("true")) {
			DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
			hcBuilder.setRoutePlanner(routePlanner);
		}

	//	logger.info("Setting headers for Timeseries service ");
		
		CloseableHttpClient client = hcBuilder.build();
		request.setHeader("Content-Type", "application/json");
		request.setHeader("Accept", "application/json");
		request.setHeader("Predix-Zone-Id", "6681de99-5e67-43ec-b0f3-fc83e7dfe394");
		request.setHeader("Authorization",
				"bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiIyOGJmODBmYjc1MTg0YTlmYmE3ZTAwNWQ3ZDZiOGM5ZSIsInN1YiI6ImhhY2tfY2xpZW50Iiwic2NvcGUiOlsidGltZXNlcmllcy56b25lcy42NjgxZGU5OS01ZTY3LTQzZWMtYjBmMy1mYzgzZTdkZmUzOTQudXNlciIsInRpbWVzZXJpZXMuem9uZXMuNjY4MWRlOTktNWU2Ny00M2VjLWIwZjMtZmM4M2U3ZGZlMzk0LmluZ2VzdCIsInRpbWVzZXJpZXMuem9uZXMuNjY4MWRlOTktNWU2Ny00M2VjLWIwZjMtZmM4M2U3ZGZlMzk0LnF1ZXJ5IiwidWFhLm5vbmUiLCJhbmFseXRpY3Muem9uZXMuZjkwNDhkZmEtZTE1ZC00YmZlLTkzZDctZmU1ODkyZTc5ZTlmLnVzZXIiLCJhenVxdWEuem9uZXMuNzRjM2Y5OGYtMWRlOS00MDk5LTk1YjMtMDJkMTE0NzEwNDQzLnVzZXIiLCJhbmFseXRpY3Muem9uZXMuNjY5NjZiMDQtNDk5YS00YzAzLWIzOGYtN2IyMjE4NTFjMDU1LnVzZXIiLCJ1YWEuYWRtaW4iLCJwcmVkaXgtYXNzZXQuem9uZXMuNjljZjBlZGItMmJhNy00MGZlLTg0ZTMtNjE0YTYxZmU0NmYwLnVzZXIiXSwiY2xpZW50X2lkIjoiaGFja19jbGllbnQiLCJjaWQiOiJoYWNrX2NsaWVudCIsImF6cCI6ImhhY2tfY2xpZW50IiwiZ3JhbnRfdHlwZSI6ImNsaWVudF9jcmVkZW50aWFscyIsInJldl9zaWciOiJkYzc2NzQ0IiwiaWF0IjoxNDgyMzkxMTkxLCJleHAiOjE1MTM5MjcxOTAsImlzcyI6Imh0dHBzOi8vZmNiN2VjOWEtM2QzNi00ZmI2LTllZDItN2M1ZTdkNjcxZjExLnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiZmNiN2VjOWEtM2QzNi00ZmI2LTllZDItN2M1ZTdkNjcxZjExIiwiYXVkIjpbImFuYWx5dGljcy56b25lcy42Njk2NmIwNC00OTlhLTRjMDMtYjM4Zi03YjIyMTg1MWMwNTUiLCJ1YWEiLCJhenVxdWEuem9uZXMuNzRjM2Y5OGYtMWRlOS00MDk5LTk1YjMtMDJkMTE0NzEwNDQzIiwidGltZXNlcmllcy56b25lcy42NjgxZGU5OS01ZTY3LTQzZWMtYjBmMy1mYzgzZTdkZmUzOTQiLCJhbmFseXRpY3Muem9uZXMuZjkwNDhkZmEtZTE1ZC00YmZlLTkzZDctZmU1ODkyZTc5ZTlmIiwiaGFja19jbGllbnQiLCJwcmVkaXgtYXNzZXQuem9uZXMuNjljZjBlZGItMmJhNy00MGZlLTg0ZTMtNjE0YTYxZmU0NmYwIl19.oc639-R01ex0EQaT_7FGK4Q2fNl2QUc0PAxhoOdzdNjoVATF4PV9Z1SQmTOHUx5jsv-3vDZTsOPTY9RayHd4TuK-BFqWrotd7WF4_z8jUe3R8z9eCJVL66M5xQSF3bgYUZIfAntpyoHKf9nD2JiqWwSyk5Lj3VQeo2GZRr0s4_kSuSdN8LfpdyVusJ1hNXfdgQHPUbBtMd2mLbXzk1vtdGWsuuE_JeUg8UZEPu4X3lCFqJUpdeNcfV6M_SQEA6F_lW0X5Zbvvmvwu1_ZvCOGPxDBcybZyxTsFgfnTZpZkwqXl3AWXtcrnJUpjfah27eYZsKw6u-wymOpAs3NupV3vQ");

		try {
		StringEntity stringEntity = new StringEntity(jsonString);
		((HttpPost) request).setEntity(stringEntity);

		HttpResponse response;
		
		//	logger.info("Executing Timeseries service ");
			
			response = client.execute(request);

			BufferedReader rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			StringBuffer result = new StringBuffer();
			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
		//	logger.info("Executed Timeseries service ");
				
			}
			success = result.toString();
			
			System.out.println("success " + success);
		//	logger.info("Calling calculationOnValues function");
		//	code = analyticTimeseries.calculationOnValues(success);
		//	logger.info("After Calling calculationOnValues function");

			//code1 = Integer.toString(code);
			

		} catch (Exception e) {
			success = "Analytics Execution Failed "+e.getMessage();
			e.printStackTrace();

		} finally {
			try {
				client.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	//	return mapper.writeValueAsString(code1);

		
		
		return success;
	}





	@Override
	public List<JSONObject> getSensorsEfficiency(String assetName) {
		JSONObject jsonObject=null;
		List<JSONObject> jsonRespList = new ArrayList<JSONObject>();
		List<ThresholdValuesEntity> thresholdList=thresholdValuesRepo.fetchThresholdValues(assetName);
		for (ThresholdValuesEntity threshodValuesEntity : thresholdList) {
			jsonObject=new JSONObject();
			String sensorName=threshodValuesEntity.getSensorName();
			jsonObject.put("sensorName", sensorName);
			jsonObject.put("realName",threshodValuesEntity.getSensorRealName());
			String jsonString = "{  \"start\": \"5mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+",\"aggregations\":[{\"type\":\"avg\",\"interval\":\"5mi\"}], \"order\": \"desc\"   } ] }";
			//String jsonString = "{  \"start\": \"45mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+",\"aggregations\":[{\"type\":\"avg\",\"interval\":\"45mi\"}], \"order\": \"desc\"   } ] }";
			String success = jsonURLParser(jsonString);
			double avgValue=fetchTimeSeriesValue(success);
			double efficiency = calcEfficiency(avgValue,threshodValuesEntity.getRatedValue());
			/*if(sensorName.equals("trnTempSn")){
			System.out.println("efficiency is ......."+efficiency);
			jsonObject.put("avg",avgValue);
			jsonObject.put("eff", Double.parseDouble(new DecimalFormat("##.##").format(efficiency/7)));
			//Double.parseDouble(new DecimalFormat("##.##").format(efficiency))
			}*/
			/*else{*/
				System.out.println("efficiency is ......."+efficiency);
				jsonObject.put("avg",avgValue);
				jsonObject.put("eff", Double.parseDouble(new DecimalFormat("##.##").format(efficiency)));
			//}
			
			jsonRespList.add(jsonObject);
		}
		return jsonRespList;
	}
	
/*	@Override
	public double fetchSingleSensorEfficiency(double sensorAvg,double ratedValue) {
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		System.out.println("before sensor efficiency*********************"+timestamp.getTime());
		String jsonString = "{  \"start\": \"5mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+",\"aggregations\":[{\"type\":\"avg\",\"interval\":\"5mi\"}], \"order\": \"desc\"   } ] }";
		//String jsonString = "{  \"start\": \"45mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+",\"aggregations\":[{\"type\":\"avg\",\"interval\":\"45mi\"}], \"order\": \"desc\"   } ] }";
		String success = jsonURLParser(jsonString);
		//double avgValue=fetchTimeSeriesValue(success);
		double efficiency = calcEfficiency(fetchSingleSensorAvgValue(sensorName));
		System.out.println("after sensor efficiency***********************"+timestamp.getTime());
		return efficiency;
	}*/
	/***********************************************************************************************************************/
	@Override
	public double fetchSingleSensorAvgValue(String sensorName) {
		System.out.println("in average calculation function......");
		String jsonString = "{  \"start\": \"5mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+",\"aggregations\":[{\"type\":\"avg\",\"interval\":\"5mi\"}], \"order\": \"desc\"   } ] }";
		System.out.println("Json string is...."+jsonString);
		//String jsonString = "{  \"start\": \"45mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+",\"aggregations\":[{\"type\":\"avg\",\"interval\":\"45mi\"}], \"order\": \"desc\"   } ] }";
		String success = jsonURLParser(jsonString);
		System.out.println("success string for average calculation....."+success);
		double avgValue=fetchTimeSeriesValue(success);
		
		return avgValue;
	}
	
	@Override
	public double fetchSingleSensorLatestValue(String sensorName) {
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		System.out.println("before sensor latest value*********************"+timestamp.getTime());
		String jsonString = "{  \"start\": \"5mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+ ",      \"order\": \"desc\" , \"limit\":1  } ] }";
		//String jsonString = "{  \"start\": \"45mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+ ",      \"order\": \"desc\" , \"limit\":1  } ] }";
		//"{  \"start\": \"1mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+ ",      \"order\": \"desc\" , \"limit\":1  } ] }";//, \"limit\":1
		String success = jsonURLParser(jsonString);
		double latestValue=fetchTimeSeriesValue(success);
		
		System.out.println("after sensor efficiency*********************"+timestamp.getTime());
		
		return latestValue;
	}
	
	@Override
	public List<JSONObject> powerAttributes(String assetName) {
		//List<ThresholdValuesEntity> list = thresholdValuesRepo.fetchThresholdValues(assetName);
		List<JSONObject> jsList=new ArrayList<JSONObject>();
		JSONObject jsObject=new JSONObject();
		if(assetName.equals("Wind-Mill")){
		double volatageValue=fetchSingleSensorLatestValue("winVolSn");
		double currentValue=fetchSingleSensorLatestValue("winCurSn");
		double taoValue=fetchSingleSensorLatestValue("taoWindVal");
		double frequencyValue=fetchSingleSensorLatestValue("feqWindVal");
		double phi=((360*taoValue)*frequencyValue);
		//Double.parseDouble(new DecimalFormat("##.###").format(powerFactor))
		double powerFactor=1.732*(volatageValue*currentValue*(Math.cos(phi)));
		jsObject.put("key",assetName);
		jsObject.put("powerFactor",Double.parseDouble(new DecimalFormat("##.##").format(powerFactor)));
		jsList.add(jsObject);
		}
		return jsList;
	}
	
	@Override
	public List<JSONObject> failureTrend(String assetName) {
		List<JSONObject> jsonList=new ArrayList<JSONObject>();
		
		long currentMillis=System.currentTimeMillis();
		System.out.println("current epoch..."+currentMillis);
		long fourDayAgoMillis=currentMillis-(86400000*4);
		System.out.println("4 day ago epoch...."+fourDayAgoMillis);
		Date startDate = new Date(fourDayAgoMillis);
		System.out.println("start date and time..."+startDate);
		Date endDate = new Date(currentMillis);
		System.out.println("end date and time...."+endDate);
		List<ApmIncidentTable> incidentList = incidentTableRepository.fetchHistoricalData(assetName, startDate, endDate);
		
		for (ApmIncidentTable apmIncidentTable : incidentList) {
			JSONObject jsObject=new JSONObject();
			System.out.println("value aa raha hai....");
			System.out.println(apmIncidentTable.getSensorId());
			System.out.println(apmIncidentTable.getSensorData());
			jsObject.put("Date",apmIncidentTable.getInitiatedTime().getTime());
			jsObject.put(apmIncidentTable.getSensorName(),apmIncidentTable.getSensorData());
			//jsObject.put("sensorName",apmIncidentTable.getSensorName());
			//jsObject.put("data",apmIncidentTable.getSensorData());
			//jsObject.put("id",apmIncidentTable.getIncidentId());
			jsonList.add(jsObject);
		}
		
		return jsonList;
	}
	@Override
	public List<JSONObject> energyAttributes(String assetName) {
   List<ThresholdValuesEntity> list = thresholdValuesRepo.fetchThresholdValues(assetName);
   List<JSONObject> jsList=new ArrayList<JSONObject>();
	JSONObject jsObject=null;
	int count=1;
    for (ThresholdValuesEntity thresholdValuesEntity : list) {
    	String sensor=thresholdValuesEntity.getSensorName();
    	if(sensor.equals("powWindMill") || sensor.equals("powSolPnl1")||sensor.equals("powSolPnl2")){
		jsObject=new JSONObject();
		
		double energy=getSensorSum(sensor);
		if(assetName.equals("Wind-Mill")){
			jsObject.put("key","Wind-Mill");
			double volatageValue=fetchSingleSensorLatestValue("winVolSn");
			double currentValue=fetchSingleSensorLatestValue("winCurSn");
			double taoValue=fetchSingleSensorLatestValue("taoWindVal");
			double frequencyValue=fetchSingleSensorLatestValue("feqWindVal");
			double phi=((360*taoValue)*frequencyValue);
			double powerFactor=1.732*(volatageValue*currentValue*(Math.cos(phi)));
			jsObject.put("powerFactor",Double.parseDouble(new DecimalFormat("##.##").format(powerFactor)));
			}
			else if(assetName.equals("Solar-Panel")){
				jsObject.put("key","Panel"+count);
				count=count+1;
			}
		//Double.parseDouble(new DecimalFormat("##.##").format(energy))
		//jsObject.put("unitName", thresholdValuesEntity.getSensorRealName());
		jsObject.put("energy",Double.parseDouble(new DecimalFormat("##.##").format(energy))+" "+"Wh");
		jsList.add(jsObject);
    	}
	}
	
	
		return jsList;
	}
	
	@Override
	public List<JSONObject> dropDownList(String assetName) {
		List<ThresholdValuesEntity> list = thresholdValuesRepo.fetchThresholdValues(assetName);
		List<JSONObject> jsList=new ArrayList<JSONObject>();
		JSONObject jsObject=null;
		int count=1;
		for (ThresholdValuesEntity thresholdValuesEntity : list) {
			jsObject=new JSONObject();
			if(assetName.equals("Solar-Panel")||assetName.equals("Wind-Mill")){
			String sensor=thresholdValuesEntity.getSensorRealName();
			double value=fetchSingleSensorLatestValue(thresholdValuesEntity.getSensorName());
			jsObject.put("sensorName", thresholdValuesEntity.getSensorRealName());
			jsObject.put("ratedValue", thresholdValuesEntity.getRatedValue()+" "+thresholdValuesEntity.getUnit());
			jsObject.put("actualValue", value+" "+thresholdValuesEntity.getUnit());
			jsList.add(jsObject);
			}
		}
		return jsList;
	}
	

	@Override
	public List<JSONObject> fetchThresholdValues(String assetName) {
		// TODO Auto-generated method stub
		
		 Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		 System.out.println("before thresholdValues*************************"+timestamp.getTime());
		List<ThresholdValuesEntity> list = thresholdValuesRepo.fetchThresholdValues(assetName);
		System.out.println("after thresholdValues***************************"+timestamp.getTime());
		List<JSONObject> jsList=new ArrayList<JSONObject>();
		JSONObject jsObj=null;
		for(ThresholdValuesEntity tve : list){
			if(!tve.getSensorName().equals("taoWindVal")){//
			jsObj=new JSONObject();
			
			double sensorAvg=fetchSingleSensorAvgValue(tve.getSensorName());
			
			//double efficiency=fetchSingleSensorEfficiency(tve.getSensorName(),tve.getRatedValue());
			double efficiency=calcEfficiency(sensorAvg, tve.getRatedValue());
			if(efficiency>100){
				jsObj.put("effeciency",100.0);
				jsObj.put("ratedValue",tve.getRatedValue()+" "+tve.getUnit());
				jsObj.put("avgValue",tve.getRatedValue()+" "+tve.getUnit());
			}
			else{
			    jsObj.put("effeciency",efficiency);
			    jsObj.put("ratedValue",tve.getRatedValue()+" "+tve.getUnit());
			    jsObj.put("avgValue",(Double.parseDouble(new DecimalFormat("##.##").format(sensorAvg))+" "+tve.getUnit()));
			}
			
			String jsonString="{  \"start\": \"5mi-ago\",  \"tags\": [ {  \"name\": "+ tve.getSensorName() + ", \"order\": \"desc\"   } ] }";
			
			double dataReliability=calcDataReliability(jsonURLParser(jsonString));    
			jsObj.put("reliability", Double.parseDouble(new DecimalFormat("##.#").format(dataReliability)));
		    
		    //sensorAvg
		    jsObj.put("assetName",tve.getAssetName());
		    jsObj.put("message", tve.getMessage());
		    jsObj.put("latestValue",(Double.parseDouble(new DecimalFormat("##.##").format(fetchSingleSensorLatestValue(tve.getSensorName())))+" "+tve.getUnit()));
		    //Double.parseDouble(new DecimalFormat("##.##").format(fetchSingleSensorLatestValue(tve.getSensorName());
		    jsObj.put("sensorName",tve.getSensorName());
		    jsObj.put("sensorRealName",tve.getSensorRealName());
		    jsObj.put("thresholdMax",tve.getThresholdMax());
		    jsObj.put("thresholdMin",tve.getThresholdMin());
		    jsObj.put("unit",tve.getUnit());
		    // Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		    //System.out.println(timestamp.getTime());
		    jsList.add(jsObj);
			}
		}
		return jsList;
	}
	
	public double calcDataReliability(String jsonString){
		
		JSONParser parser = new JSONParser();
		JSONObject stats=null;
		double currentValue= 0.0;
		long count=0;
		int h = 0;
		long rawcount =0;
		JSONObject json=null;
		try {
			json = (JSONObject) parser.parse(jsonString);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.println("JSON : " + json);

		JSONArray tags = (JSONArray) json.get("tags");
		//{"tags":[{"name":"feqWindVal","results":[{"values":[],"attributes":{}}],"stats":{"rawCount":0}}]}
		for (Object t : tags) {
			// valuesOfSensor=new ArrayList<Integer>();
			JSONObject tag = (JSONObject) t;
			 stats = (JSONObject) tag.get("stats");

			System.out.println("stats is " +stats);
			rawcount = (long) stats.get("rawCount");
			System.out.println("rawcount is....."+rawcount);
			// JSONArray results = (JSONArray) tag.get("results");
			 //System.out.println("result is....."+results);
			 
			/*for (Object r : results) 
			{
				JSONObject result = (JSONObject) r;
				JSONArray values = (JSONArray) result.get("values");
				
				List<List<Object>> val = values;
				
				count = val.size();
				
				// LOOP OF VALUES
				System.out.println("look here......");
				while (h < val.size()) 
				{
				//System.out.println("Data from sensor: " + val.get(h).get(1));
				long v = (long) val.get(h).get(1);
				//System.out.println(v);
				currentValue = v;
				System.out.println(currentValue);
				
				h++;
				}//while end
			}//for end
*/		}//master for end
		double dataReliability=rawcount/5;// for 5 min
		//Double.parseDouble(new DecimalFormat("##.#").format(dataReliability))
		return Double.parseDouble(new DecimalFormat("##.#").format(dataReliability));
		}
	
		
		//count = Long.parseLong(rawcount);
		
	
	
	@Override
	public double calcEfficiency(double sensorAvgValue,double ratedValue){
		System.out.println("sensor avg is......."+sensorAvgValue);
		System.out.println("sensor rated value is"+ratedValue);
		double efficiency=(sensorAvgValue/ratedValue)*100;
		System.out.println("efficiency"+efficiency);
		//Double.parseDouble(new DecimalFormat("##.##").format(efficiency);
		return Double.parseDouble(new DecimalFormat("##.#").format(efficiency));
		
	}




	@Override
	public double getSensorSum(String sensorName) {
		System.out.println("first line.......");
		 Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		long currentTimeStamp=timestamp.getTime();
		long milliSecPassed=getSeconds();
		long startTime=currentTimeStamp-milliSecPassed;
		System.out.println("currentTimeStamp Time is..."+currentTimeStamp);
		System.out.println("Start Time is..."+startTime);//+startTime+
		String jsonString = "{  \"start\": "+startTime+", \"tags\": [ {  \"name\":"+sensorName+",\"aggregations\":[{\"type\":\"sum\",\"sampling\":{\"datapoints\":1}}]  } ] }";
		//String jsonString = "{  \"start\": 1497535821024,\"end\":1497535861065 , \"tags\": [ {  \"name\":"+sensorName+",\"aggregations\":[{\"type\":\"sum\",\"sampling\":{\"datapoints\":1}}]  } ] }";//,\"interval\":\"5mi\"
		//"{  \"start\": \"1mi-ago\",  \"tags\": [ {  \"name\":"+sensorName+ ",      \"order\": \"desc\" , \"limit\":1  } ] }";//, \"limit\":1
		System.out.println("Json String....."+jsonString);
		String success = jsonURLParser(jsonString);
		System.out.println(success);
		double sum=fetchTimeSeriesValue(success)/3600;
		//Start:1497535861069
		//end:1497535821024
		return sum;
		
	}





	@Override
	public long getSeconds() {
	/*	DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");//HH:mm:ss
		
		System.out.println(dateFormat.format(date));
		String swSpinnerTimeValue=dateFormat.format(date);
		System.out.println("String value is for full time "+swSpinnerTimeValue);*/
		
		Date date = new Date();
		DateFormat dateFormatHour = new SimpleDateFormat("HH");
		System.out.println(dateFormatHour.format(date));
		String hours=dateFormatHour.format(date);
		System.out.println("String value is for Hour "+hours);
		
		DateFormat dateFormatMin = new SimpleDateFormat("mm");
		System.out.println(dateFormatMin.format(date));
		String minutes=dateFormatMin.format(date);
		System.out.println("String value is for min "+minutes);
		
		DateFormat dateFormatSec = new SimpleDateFormat("ss");
		System.out.println(dateFormatSec.format(date));
		String seconds=dateFormatSec.format(date);
		System.out.println("String value is for min "+seconds);
		
		long totalSec=(Long.parseLong(hours)*3600+Long.parseLong(minutes)*60+Long.parseLong(seconds))*1000;
		System.out.println("total second is...."+totalSec);
		
			
		
		return totalSec;
	}





	@Override
	public String checkJson(JSONObject message) {
		//JSONArray jsonArray = new JSONArray(message);
          JSONObject jsObj = new JSONObject();
        //for(int i=0;i<jsonArray.length();i++)
      //  {
		//JSONObject jsObj=message;
		System.out.println("in method.....");
		System.out.println("JSON IS...."+message);
          //  JSONObject jsonObject1 = jsonArray.getJSONObject(i);
           /* String value1 = jsonObject1.optString("key1");
            String value2 = jsonObject1.optString("key2");*/
		String value1=(String) jsObj.get("serviceName");
		
        System.out.println("value1 is ..... "+value1);
        String date1=(String) jsObj.get("sendingDate");
        System.out.println("date in string......."+date1);          
            //Scanner scan = new Scanner(System.in);
           // String s = scan.nextLine();
          //  String dt =  "2012-10-01T09:45:00.000+02:00";
             //2017-08-16T11:09:07.791+0200
		//String testString="2017-08-16T11:09:07.791+0200";
		//System.out.println("test string .... "+testString);
		String testString2=date1.replace("T"," ");//testString 2 goes here
		System.out.println("test string 2  without T... "+testString2);
		System.out.println("before parts... ");
		String[] parts=testString2.split("\\+");
		System.out.println("after parts... ");
		String part1=parts[0];
		System.out.println("part1.....is...."+part1);
             String date="2017-08-16 11:09:07.791";
             System.out.println("date in string"+date);
            //OffsetDateTime odt = OffsetDateTime.parse(date);
            
           // date = String.valueOf(odt.toEpochSecond()*1000); //odt.toEpochSecond()*1000;
           //System.out.println("value of odt..."+odt.toEpochSecond()*1000);

           // String value3 = date;
             try {
				Long millis = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS").parse(part1).getTime();
				 System.out.println("****************date is***********************" + part1 +"*****");
				 System.out.println("epoch is....."+millis);
				 String returnString="the date is..."+part1+"....the epoch time is..."+millis+"...original date was...."+date1; 
				 return returnString;
             } catch (java.text.ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return "Parse Error Exception";
			}
			
           
           
            
       // }
    

		
	}








	
	


	}
