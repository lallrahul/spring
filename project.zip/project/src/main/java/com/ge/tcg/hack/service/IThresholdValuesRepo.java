package com.ge.tcg.hack.service;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ge.tcg.hack.dto.ThresholdValuesEntity;

@Repository
public interface IThresholdValuesRepo extends PagingAndSortingRepository<ThresholdValuesEntity, Long> {

	@Query("SELECT t FROM ThresholdValuesEntity t WHERE t.assetName = ?1")
	List<ThresholdValuesEntity> fetchThresholdValues(String assetName);
	
	@Query("SELECT DISTINCT t.assetName FROM ThresholdValuesEntity t")
	List<String> fetchDistinctAssetName();
	
	
	@Query("SELECT DISTINCT t.channel FROM ThresholdValuesEntity t WHERE t.assetName= ?1")
	String fetchChannel(String assetName);
	
	@Query("SELECT DISTINCT t.status FROM ThresholdValuesEntity t WHERE t.assetName= ?1")
	String fetchStatus(String assetName);
	
	@Query("SELECT DISTINCT t.preStatus FROM ThresholdValuesEntity t WHERE t.assetName= ?1")
	String getPreStatus(String assetName);
	
	@Modifying
	@Transactional
	@Query("UPDATE ThresholdValuesEntity t SET t.preStatus= ?1 WHERE t.assetName= ?2 ")
	void updatePreviousStatus(String status,String assetName);
	
	@Modifying
	@Transactional
	@Query("UPDATE ThresholdValuesEntity t SET t.status= ?1 WHERE t.assetName= ?2 ")
	void updateStatus(String status,String assetName);
	/*@Query("SELCT t.assetName FROM ThresholdValuesEntity t WHERE t.sensorName = ?1")
	String getAssetName(String sensorName); */

}
