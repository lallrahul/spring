package com.ge.tcg.hack.repositories;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.ge.tcg.hack.dto.ApmIncidentTable;

public interface IIncidentTableRepo extends PagingAndSortingRepository<ApmIncidentTable, Integer>{

	
	/*@Query("select t.sensorData,t.sensorName,t.sensorData,t.initiatedTime from ApmIncidentTable t where t.assetName = ?1 AND (t.initiatedTime <= ?3 AND t.initiatedTime >= ?2)")
	List<ApmIncidentTable> fetchHistoricalData(String assetName,Date startDate,Date endDate);*/
	
	@Query("select t from ApmIncidentTable t where t.assetName = ?1 AND (t.initiatedTime <= ?3 AND t.initiatedTime >= ?2)")
	List<ApmIncidentTable> fetchHistoricalData(String assetName,Date startDate,Date endDate);
	
}
