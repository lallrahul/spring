package com.ge.tcg.hack.controller;

import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.hibernate.tuple.GenerationTiming;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ge.tcg.hack.dto.ApmIncidentTable;
import com.ge.tcg.hack.dto.AssetMonitoring;
import com.ge.tcg.hack.dto.MessagePopTable;
import com.ge.tcg.hack.dto.SensorAlertCheck;
import com.ge.tcg.hack.dto.ThresholdValuesEntity;
import com.ge.tcg.hack.service.IAssetSummaryDetailsService;


@RestController
public class SensorController {
	
	@Autowired
	IAssetSummaryDetailsService objAssetSummaryDetails;
	
	
	/********************************************************************/
/*	@RequestMapping(value="/saveCustomerDetails" ,method = RequestMethod.POST, produces = "application/json", consumes="application/json", headers= "Accept=application/json")
	public List<IncidentEntity> saveCustomerDetails(@RequestBody JSONObject customerDTO) throws Exception {
		//System.out.println("data______"+customerDTO.toString()); 
		return iCustomerService.saveCustomerDetails(customerDTO);
		 
	} 
*/
	
	@RequestMapping(value="/checkJson" ,method = RequestMethod.POST, produces = "application/json", consumes="application/json", headers= "Accept=application/json")
	public String checkJson(@RequestBody JSONObject message) throws Exception {
		//System.out.println("data______"+customerDTO.toString()); 
		String value=objAssetSummaryDetails.checkJson(message);
		 return value;
	} 
	
	/*@RequestMapping(value="/checkJson" ,method = RequestMethod.GET)
	public void checkJson() throws Exception {
		//System.out.println("data______"+customerDTO.toString()); 
		objAssetSummaryDetails.checkJson();
		 
	}*/
	/********************************************************************/
	/*@RequestMapping(value = "/getSeconds", method = RequestMethod.GET)// NR
	public long getSeconds() {
		long sec=objAssetSummaryDetails.getSeconds();//in calculation seconds after 12am for energy calculation
		return sec;
	}*/
	
    @RequestMapping(value = "/energyAttributes", method = RequestMethod.GET)
	public List<JSONObject> energyAttributes(@RequestParam String assetName) {
		List<JSONObject> list=objAssetSummaryDetails.energyAttributes(assetName);//energy generation calculation from 12am
		return list;
	}
    
    @RequestMapping(value = "/dropDownList", method = RequestMethod.GET)
   	public List<JSONObject> dropDownList(@RequestParam String assetName) {
   		List<JSONObject> list=objAssetSummaryDetails.dropDownList(assetName);
   		return list;
   	}
    
    
    /*******************************************************************/
    @RequestMapping(value = "/failureTrend", method = RequestMethod.GET)
   	public List<JSONObject> failureTrend(@RequestParam String assetName) {
   		List<JSONObject> list=objAssetSummaryDetails.failureTrend(assetName);
   		return list;
   	}
    
     /*****************************************************************/
    
    @RequestMapping(value = "/powerAttributes", method = RequestMethod.GET)
   	public List<JSONObject> powerAttributes(@RequestParam String assetName) {
   		List<JSONObject> list=objAssetSummaryDetails.powerAttributes(assetName);
   		return list;
   	}
	
	/*@RequestMapping(value = "/getSensorData", method = RequestMethod.GET)//NR
	public String getSensorData(@RequestParam String sensorName) {
		String json=objAssetSummaryDetails.fetchAllSensorData(sensorName);
		return json;
	}*/
	
	
	/*@RequestMapping(value = "/getSensorSum", method = RequestMethod.GET)//NR
	public double getSensorSum(@RequestParam String sensorName) {
		double sum=objAssetSummaryDetails.getSensorSum(sensorName);
		return sum;
	}*/
	
    @RequestMapping(value = "/getValue", method = RequestMethod.GET)
	public double getValue() {
    
    	
    	
    	
    	//long millis=Long.parseLong("1505999010000");
    	long millis=System.currentTimeMillis(); //epoch to date
    	Date date = new Date(millis);
    	System.out.println("date is..."+date);
    	DateFormat dateFormatHour = new SimpleDateFormat("HH");
    	String hours=dateFormatHour.format(date);
		System.out.println("String value is for Hour "+hours);
		
		System.out.println("current epoch time....by System class"+System.currentTimeMillis());
		
		System.out.println("using instant...."+Instant.now().toEpochMilli());
		System.out.println("testing Instant.now()"+Instant.now());
    	
    	
    	/*SimpleDateFormat formatter = new SimpleDateFormat("dd MMMM yyyy hh:mm:ss a");
    	String s = formatter.format(new Date());
    	
    	 
		try {
			System.out.println("date is..."+s);
			Date date = formatter.parse(s);
			
			System.out.println("Sample date...."+date);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
    	
    	/*
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    	Date c= sdf.parse("2015-05-26");
    	String date=sdf.format(c);
    	System.out.println(date);
    	
    	
    	
    	SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMMM yyyy hh:mm:ss a");
		Date currentDate = new Date();
		
			Date formattedDate = dateFormat.parse(source)
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Format formatter = new SimpleDateFormat("dd MMMM yyyy hh:mm:ss a"); 
        // String s = formatter.format(new Date());
		Date date = new Date();
		*/
		
    	
    	
		return 32.22;
	}
    
    
	@RequestMapping(value = "/alertMessagePop", method = RequestMethod.GET)
	public JSONObject alertMessagePop(@RequestParam String assetName) {
		JSONObject list=objAssetSummaryDetails.alertMessagePop(assetName);
		return list;
	}
	
	@RequestMapping(value = "/checkEachSensor", method = RequestMethod.GET)
	public List<SensorAlertCheck> checkEachSensor() {
		List<SensorAlertCheck> list=objAssetSummaryDetails.checkEachSensor();
		return list;
	}
	
	
	/*@RequestMapping(value = "/getSensorsEfficiency", method = RequestMethod.GET)//NR
	public List<JSONObject> getSensorsEfficiency(@RequestParam String assetName) {
		List<JSONObject> json=objAssetSummaryDetails.getSensorsEfficiency(assetName);
		return json;
	}*/
		
	@RequestMapping(value = "/assetMonitor", method = RequestMethod.GET)
	public List<AssetMonitoring> assetMonitor(@RequestParam String assetName) {
		List<AssetMonitoring> list = objAssetSummaryDetails.assetMonitor(assetName);
		return list;
	}
	
	
	/*@RequestMapping(value = "/checkAverageData", method = RequestMethod.GET)//NR
	public List<JSONObject> checkAverageData(@RequestParam String assetName) {
		List<JSONObject> list = objAssetSummaryDetails.checkAverageData(assetName);
		return list;
	}*/
	
	
	@RequestMapping(value = "/getThresholdValues", method = RequestMethod.GET)
	public List<JSONObject> getThresholdValues(@RequestParam String assetName) {
		List<JSONObject> list = objAssetSummaryDetails.fetchThresholdValues(assetName);
		return list;
	}
	
/*	@RequestMapping(value = "/fetchAverageViaSensor", method = RequestMethod.GET)//NR
	public Map<String,String> fetchAverageViaSensor() {
		
				Map<String,String> map=objAssetSummaryDetails.fetchAverageViaSensor();
				return map;
		
	}*/
	
	
	
	@RequestMapping(value="/fetchIncidentTable",method=RequestMethod.GET)
	public List<ApmIncidentTable> fetchIncidentTable(@RequestParam String assetName) {
		List<ApmIncidentTable> incident_list=objAssetSummaryDetails.fetchIncidentTable(assetName);
		return incident_list;
	}
	/*
	@RequestMapping(value="/fetchBoomBarrier",method=RequestMethod.GET)
	public Map<String,String> fetchBoomBarrier() {
		Map<String,String> incident_list=objAssetSummaryDetails.fetchBoomBarrier();
		return incident_list;
	}
	
	*/
	/*@RequestMapping(value = "/getSensorData", method = RequestMethod.GET)
	public List<AssetSummaryDetailsDTO> fetchAssetSummaryDetails() {

		List<AssetSummaryDetailsDTO> assetSummaryDetailsDTOList = new ArrayList<AssetSummaryDetailsDTO>();
		AssetInfoDTO objAssetInfoDTO;
		AssetSummaryDetailsDTO objAssetSummaryDetailsDTO = new AssetSummaryDetailsDTO();
		
		try {
			objAssetInfoDTO = new AssetInfoDTO();
			objAssetInfoDTO = objAssetSummaryDetails.fetchSkuDetails();
			objAssetSummaryDetailsDTO.setSkuDetails(objAssetInfoDTO);
			
			objAssetInfoDTO = new AssetInfoDTO();
			objAssetInfoDTO = objAssetSummaryDetails.fetchBomDetails();
			objAssetSummaryDetailsDTO.setBomDetails(objAssetInfoDTO);
			
			objAssetInfoDTO = new AssetInfoDTO();
			objAssetInfoDTO = objAssetSummaryDetails.fetchClassDetails();
			objAssetSummaryDetailsDTO.setClassDetails(objAssetInfoDTO);
			
			
			objAssetInfoDTO = new AssetInfoDTO();
			objAssetInfoDTO = objAssetSummaryDetails.fetchDeviceDetails();
			objAssetSummaryDetailsDTO.setDeviceDetails(objAssetInfoDTO);
			
			
			objAssetInfoDTO = new AssetInfoDTO();
			objAssetInfoDTO = objAssetSummaryDetails.fetchProductDetails();
			objAssetSummaryDetailsDTO.setProductHierarchyDetails(objAssetInfoDTO);
			
			assetSummaryDetailsDTOList.add(objAssetSummaryDetailsDTO);
			
		} catch (Exception e) {
			e.printStackTrace();		
		}  
		return assetSummaryDetailsDTOList;
	}
	
	
*/}
