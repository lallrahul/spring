package com.ge.tcg.hack.service;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ge.tcg.hack.dto.ThresholdValuesEntity;

@Repository
public interface GetAllAssetNamesRepo extends PagingAndSortingRepository<ThresholdValuesEntity, Long> {

	@Query("SELECT DISTINCT t.assetName FROM ThresholdValuesEntity t")
	List<String> fetchDistinctAssetName();
	
	
	//substitute done
}
