package com.ge.tcg.hack.service;

import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;

import com.ge.tcg.hack.dto.ApmIncidentTable;
import com.ge.tcg.hack.dto.AssetMonitoring;
import com.ge.tcg.hack.dto.MessagePopTable;
import com.ge.tcg.hack.dto.SensorAlertCheck;
import com.ge.tcg.hack.dto.ThresholdValuesEntity;



public interface IAssetSummaryDetailsService {
	
	public String fetchAllSensorData(String sensorName);
	
	//public String fetchAverageViaSensor();
   // public Map<String,String> fetchAverageViaSensor();

	public List<ApmIncidentTable> fetchIncidentTable(String assetName);

	public List<JSONObject> fetchThresholdValues(String assetName);

	public List<AssetMonitoring> assetMonitor(String assetName);

	public List<JSONObject> checkAverageData(String assetName);// for the new average calculation

	public List<JSONObject> getSensorsEfficiency(String assetName);

	public JSONObject alertMessagePop(String caseCode);

	//double fetchSingleSensorEfficiency(String sensorName);

	double fetchSingleSensorAvgValue(String sensorName);

	public List<SensorAlertCheck> checkEachSensor();

	String calculateCaseCode(String assetName);

	double fetchSingleSensorLatestValue(String sensorName);

	public double getSensorSum(String sensorName);

	public List<JSONObject> energyAttributes(String assetName);

	public long getSeconds();
	
	public String generateAlertMessage(String caseCode);

	public List<JSONObject> powerAttributes(String assetName);

	public List<JSONObject> dropDownList(String assetName);

	double calcEfficiency(double sensorValue, double ratedValue);

	//public void checkJson();

	public String checkJson(JSONObject message);

	public List<JSONObject> failureTrend(String assetName);

	
	
	


//	public Map<String, String> fetchBoomBarrier();
	
	/*public AssetInfoDTO fetchSkuDetails();
	
	public AssetInfoDTO fetchBomDetails();
	
	public AssetInfoDTO fetchClassDetails();

	public AssetInfoDTO fetchDeviceDetails();
	
	public AssetInfoDTO fetchProductDetails();
	*/
}
