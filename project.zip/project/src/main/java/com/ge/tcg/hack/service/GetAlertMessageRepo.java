package com.ge.tcg.hack.service;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ge.tcg.hack.dto.MessagePopTable;

@Repository
public interface GetAlertMessageRepo extends PagingAndSortingRepository<MessagePopTable, Long>{
	@Query("SELECT t.status FROM MessagePopTable t WHERE t.caseString = ?1 AND t.assetName= ?2")
	String fetchStatus(String caseString,String assetName);
}

//substitute written
