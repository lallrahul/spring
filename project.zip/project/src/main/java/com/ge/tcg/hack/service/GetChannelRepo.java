package com.ge.tcg.hack.service;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ge.tcg.hack.dto.MessagePopTable;

@Repository
public interface GetChannelRepo extends PagingAndSortingRepository<MessagePopTable, Long>{

	@Query("SELECT DISTINCT t.channel FROM MessagePopTable t WHERE t.caseString = ?1 AND t.assetName= ?2")
	String fetchChannel(String caseString,String assetName);
	
}

//substitute made