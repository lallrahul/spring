package com.ge.tcg.hack.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
//tabel dependency eliminated...
@Entity
@Table(name="messagePopTable")
public class MessagePopTable {

	@Id
	@SequenceGenerator(name="seq",sequenceName="messagePop_seq")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq")
	private long caseId;
	@Column(name="assetName")
	private String assetName;
	@Column(name="caseString")
	private String caseString;
	@Column(name="message")
	private String message;
	@Column(name="status")
	private String status;
	@Column(name="preStatus")
	private String preStatus;
	@Column(name="channel")
	private String channel;
	public long getCaseId() {
		return caseId;
	}
	public void setCaseId(long caseId) {
		this.caseId = caseId;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getCaseString() {
		return caseString;
	}
	public void setCaseString(String caseString) {
		this.caseString = caseString;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPreStatus() {
		return preStatus;
	}
	public void setPreStatus(String preStatus) {
		this.preStatus = preStatus;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	
	
}
