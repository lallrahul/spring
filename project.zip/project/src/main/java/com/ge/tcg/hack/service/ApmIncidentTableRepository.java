package com.ge.tcg.hack.service;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ge.tcg.hack.dto.ApmIncidentTable;
import com.ge.tcg.hack.dto.ThresholdValuesEntity;


@Repository
public interface ApmIncidentTableRepository extends PagingAndSortingRepository<ApmIncidentTable,Integer>{
	
	@Query("SELECT t FROM ApmIncidentTable t WHERE t.assetName = ?1 ORDER BY incidentId DESC")
	List<ApmIncidentTable> fetchIncidentTable(String assetName);
	
}
