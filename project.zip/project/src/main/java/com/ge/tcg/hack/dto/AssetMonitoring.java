package com.ge.tcg.hack.dto;



public class AssetMonitoring {

	private String sensorTag; 
	private String sensorRealName;
	private String alertStatus;
	private double deltaToUpperThreshold;
	private double deltaToLowerThreshold;
	private String lastMtrReading;
	private String unit;
	private double thresholdMin;
	private double thresholdMax;
	private double latestValue;
	private double currentValue;
    private double ratedValue;
    private String sensorType;
	public String getSensorTag() {
		return sensorTag;
	}
	public void setSensorTag(String sensorTag) {
		this.sensorTag = sensorTag;
	}
	public String getSensorRealName() {
		return sensorRealName;
	}
	public void setSensorRealName(String sensorRealName) {
		this.sensorRealName = sensorRealName;
	}
	public String getAlertStatus() {
		return alertStatus;
	}
	public void setAlertStatus(String alertStatus) {
		this.alertStatus = alertStatus;
	}
	public double getDeltaToUpperThreshold() {
		return deltaToUpperThreshold;
	}
	public void setDeltaToUpperThreshold(double deltaToUpperThreshold) {
		this.deltaToUpperThreshold = deltaToUpperThreshold;
	}
	public double getDeltaToLowerThreshold() {
		return deltaToLowerThreshold;
	}
	public void setDeltaToLowerThreshold(double deltaToLowerThreshold) {
		this.deltaToLowerThreshold = deltaToLowerThreshold;
	}
	public String getLastMtrReading() {
		return lastMtrReading;
	}
	public void setLastMtrReading(String lastMtrReading) {
		this.lastMtrReading = lastMtrReading;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public double getThresholdMin() {
		return thresholdMin;
	}
	public void setThresholdMin(double thresholdMin) {
		this.thresholdMin = thresholdMin;
	}
	public double getThresholdMax() {
		return thresholdMax;
	}
	public void setThresholdMax(double thresholdMax) {
		this.thresholdMax = thresholdMax;
	}
	public double getLatestValue() {
		return latestValue;
	}
	public void setLatestValue(double latestValue) {
		this.latestValue = latestValue;
	}
	public double getCurrentValue() {
		return currentValue;
	}
	public void setCurrentValue(double currentValue) {
		this.currentValue = currentValue;
	}
	public double getRatedValue() {
		return ratedValue;
	}
	public void setRatedValue(double ratedValue) {
		this.ratedValue = ratedValue;
	}
	public String getSensorType() {
		return sensorType;
	}
	public void setSensorType(String sensorType) {
		this.sensorType = sensorType;
	}
	
    
    
    
	
	
	
	
	/**************************************************************************************/
	
	/**************************************************************************************/
	
	
	
}
